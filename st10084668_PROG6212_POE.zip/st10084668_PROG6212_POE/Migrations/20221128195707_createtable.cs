﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace st10084668_PROG6212_POE.Migrations
{
    public partial class createtable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Module",
                columns: table => new
                {
                    moduleID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    username = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    moduleCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    moduleName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    credits = table.Column<int>(type: "int", nullable: false),
                    classHrsPerWeek = table.Column<int>(type: "int", nullable: false),
                    weeksInSemester = table.Column<int>(type: "int", nullable: false),
                    startDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    selfStudyHrs = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Module", x => x.moduleID);
                });

            migrationBuilder.CreateTable(
                name: "StudyPlanner",
                columns: table => new
                {
                    plannerID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    username = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    day = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    moduleCode = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StudyPlanner", x => x.plannerID);
                });

            migrationBuilder.CreateTable(
                name: "StudySession",
                columns: table => new
                {
                    SSID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    username = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    dateOfStudy = table.Column<DateTime>(type: "datetime2", nullable: false),
                    moduleCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    hoursWorked = table.Column<int>(type: "int", nullable: false),
                    workweek = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StudySession", x => x.SSID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Module");

            migrationBuilder.DropTable(
                name: "StudyPlanner");

            migrationBuilder.DropTable(
                name: "StudySession");
        }
    }
}
