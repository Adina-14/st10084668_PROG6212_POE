﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using st10084668_PROG6212_POE.Model;

namespace st10084668_PROG6212_POE.Model
{
    public class AuthDbContext: IdentityDbContext
    {
        public AuthDbContext(DbContextOptions<AuthDbContext>options): base(options)
        {

        }
        public DbSet<st10084668_PROG6212_POE.Model.Module> Module { get; set; }
        public DbSet<st10084668_PROG6212_POE.Model.StudyPlanner> StudyPlanner { get; set; }
        public DbSet<st10084668_PROG6212_POE.Model.StudySession> StudySession { get; set; }
      
        
    }
}
