﻿using Microsoft.VisualBasic;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace st10084668_PROG6212_POE.Model
{
    [Table("Module")]
    public class Module
    {
        //Declare + get and set
        [Key]
        [Required]
        public int moduleID  {get;set;}
     
        public string username {get;set;}
        [Required]
        public string moduleCode { get;set;}
        [Required]
        public string moduleName { get;set;}
        [Required]
        public int credits {get;set;}
        [Required]
        public int classHrsPerWeek {get;set;}
        [Required]
        public int weeksInSemester {get;set;}
        [Required]
        public DateTime startDate {get;set;}
       
        public int selfStudyHrs { get;set;}

    }
}
