﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace st10084668_PROG6212_POE.Model
{
    [Table("StudyPlanner")]
    public class StudyPlanner
    {
        //Declare + get and set
        [Key]
        [Required]
        public int plannerID { get; set; }
 
        public string username { get; set; }
        [Required]
        public string day { get; set; }

        public string moduleCode { get; set; }
    }
}
