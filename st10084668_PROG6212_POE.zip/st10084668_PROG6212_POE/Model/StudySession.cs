﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace st10084668_PROG6212_POE.Model
{
    [Table("StudySession")]
    public class StudySession
    {
        //Declare + get and set
        [Key]
        [Required]
        public int SSID { get; set; }
      
        public string username { get; set; }
        [Required]
        public DateTime dateOfStudy { get; set; }
        [Required]
        public string moduleCode { get; set; }
        [Required]
        public int hoursWorked { get; set; }
       
        public int workweek { get; set; }

    }
}
