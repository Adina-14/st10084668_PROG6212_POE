﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using st10084668_PROG6212_POE.Model;
using st10084668_PROG6212_POE.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace st10084668_PROG6212_POE.Pages
{
    [Authorize]
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly AuthDbContext context;

        public IndexModel(ILogger<IndexModel> logger, AuthDbContext context)
        {
            _logger = logger;
            this.context = context;
        }
        [BindProperty]
        public string day { get; set; }
        public string remMod { get; set; }
        public void OnGet()
        {
            day = DateTime.Today.DayOfWeek.ToString();
            
            
            remMod = "No Module";
            var Searchday = from rec in context.StudyPlanner
                            where rec.username == User.Identity.Name && rec.day == day
                            select rec;

            var dayList = Searchday.ToList();

            if (Searchday != null || (dayList.Any()))    
            {
                foreach (StudyPlanner qm in dayList)
                {
                  
                    remMod = qm.moduleCode; //get module for this day
                }

            }//end if 
            
            }
    }
}
