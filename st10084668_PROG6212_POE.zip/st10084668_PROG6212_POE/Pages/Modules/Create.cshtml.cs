﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using st10084668_POE_lib;
using st10084668_PROG6212_POE.Model;

namespace st10084668_PROG6212_POE.Pages.Modules
{
    public class CreateModel : PageModel
    {
        private readonly st10084668_PROG6212_POE.Model.AuthDbContext _context;

        public CreateModel(st10084668_PROG6212_POE.Model.AuthDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Module Module { get; set; }

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            //check if user is entering a module that doesnt exist
            var Searchmod = from rec in _context.Module //search module table to find module
                               where rec.username == User.Identity.Name && rec.moduleCode == Module.moduleCode
                               select rec;

            var modList = Searchmod.ToList();
            if (Searchmod == null || (!modList.Any()))    //if the module does not exists already
            {
                
                Module.username = User.Identity.Name;//getting username
                //get class library to do selfstudyhrs calculation
                Module.selfStudyHrs = Calculations.CalcHoursPerWeek(Module.credits,Module.weeksInSemester,Module.classHrsPerWeek);
                _context.Module.Add(Module);
                await _context.SaveChangesAsync();//save to database
             
                return RedirectToPage("./Index");//redirected back to module index page

            }
            ModelState.AddModelError("", "Module already Exists!");
            //if the module does exist the user will stay on the page
            return Page();

        }
    }
}
