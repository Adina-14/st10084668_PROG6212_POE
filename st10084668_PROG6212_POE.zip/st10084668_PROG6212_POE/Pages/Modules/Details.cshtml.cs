﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using st10084668_POE_lib;
using st10084668_PROG6212_POE.Model;
using st10084668_PROG6212_POE.ViewModel;

namespace st10084668_PROG6212_POE.Pages.Modules
{
    public class DetailsModel : PageModel
    {
        private readonly st10084668_PROG6212_POE.Model.AuthDbContext _context;

        public DetailsModel(st10084668_PROG6212_POE.Model.AuthDbContext context)
        {
            _context = context;
        }

        public Module Module { get; set; }

        //Declare variables
        public int remainingSelfstudyhours { get; set; }
        public int hoursSpentThisWeek { get; set; }
        public int extraHours { get; set; }
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Module = await _context.Module.FirstOrDefaultAsync(m => m.moduleID == id);

            //initialize variables
            DateTime startDate = DateTime.Now;
            int selfstudyhrs = 0;
            int count = 0;
            extraHours = 0;

            //Query to get the start date of semester and self study hours per week
            var Querydb = _context.Module.Where(u => u.username == User.Identity.Name && u.moduleCode == Module.moduleCode);
            var data = Querydb.ToList();
            foreach (Module qm in data)
            {
                startDate = qm.startDate;
                selfstudyhrs = qm.selfStudyHrs;
            }

            //calculate current week
            int currentweek = Calculations.currentWeek(startDate);

            //Query to get study session details
            var Querydb2 = _context.StudySession.Where(u => u.username == User.Identity.Name && u.moduleCode == Module.moduleCode);
            var data2 = Querydb2.ToList();

            foreach (StudySession qs in data2)
            {
                if (currentweek == qs.workweek)//if the work was done in the current week
                {
                    count += qs.hoursWorked;//Add up hours worked in the current week
                }
            }

            //set values
            remainingSelfstudyhours = selfstudyhrs - count;//calculate remaining hours
             hoursSpentThisWeek = count;//calculate how many hours the student studied for 



            //if the total hours studied for the week is greater than the required self study hours
            if (count > selfstudyhrs)
            {
                extraHours = hoursSpentThisWeek - selfstudyhrs;//calculate remaining hrs
                remainingSelfstudyhours = 0;//set remaining hours to zero
            }


            if (Module == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
