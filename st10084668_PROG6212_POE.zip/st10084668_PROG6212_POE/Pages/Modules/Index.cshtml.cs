﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using st10084668_PROG6212_POE.Model;
using st10084668_PROG6212_POE.ViewModel;

namespace st10084668_PROG6212_POE.Pages.Modules
{
    public class IndexModel : PageModel
    {
        private readonly st10084668_PROG6212_POE.Model.AuthDbContext _context;


        public IndexModel(st10084668_PROG6212_POE.Model.AuthDbContext context)
        {
            _context = context;
        }

        public IList<Module> Module { get;set; }

        public async Task OnGetAsync()
        {
           //Makes sure the user only sees their own data
            Module = await _context.Module.Where(g => g.username == User.Identity.Name).ToListAsync();
        }
    }
}
