﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using st10084668_PROG6212_POE.Model;

namespace st10084668_PROG6212_POE.Pages.StudyPlanners
{
    public class CreateModel : PageModel
    {
        private readonly st10084668_PROG6212_POE.Model.AuthDbContext _context;

        public CreateModel(st10084668_PROG6212_POE.Model.AuthDbContext context)
        {
            _context = context;
        }
        public List<SelectListItem> Options { get; set; }
        
        public IActionResult OnGet()
        {
            Options = new SelectList(_context.Module.Where(g => g.username == User.Identity.Name), "moduleCode","moduleCode").ToList();
            return Page();
        }

        [BindProperty]
        public StudyPlanner StudyPlanner { get; set; }
        

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            //check if user already set a module to study on this day
            var Searchday = from rec in _context.StudyPlanner
                            where rec.username == User.Identity.Name && rec.day == StudyPlanner.day
                            select rec;

            var dayList = Searchday.ToList();//make list

            if (Searchday == null || (!dayList.Any()))    //if the day does not exists already
            {
                //set username 
                StudyPlanner.username = User.Identity.Name;
                _context.StudyPlanner.Add(StudyPlanner);
                await _context.SaveChangesAsync();//add to database

                return RedirectToPage("./Index");//takes user back to index page
            }
            ModelState.AddModelError("", "You have already chosen a module to study on this day!");
            Options = new SelectList(_context.Module.Where(g => g.username == User.Identity.Name), "moduleCode", "moduleCode").ToList();
            return Page();//reset page

        }
    }
}
