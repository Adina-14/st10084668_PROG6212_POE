﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using st10084668_PROG6212_POE.Model;

namespace st10084668_PROG6212_POE.Pages.StudyPlanners
{
    public class DeleteModel : PageModel
    {
        private readonly st10084668_PROG6212_POE.Model.AuthDbContext _context;

        public DeleteModel(st10084668_PROG6212_POE.Model.AuthDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public StudyPlanner StudyPlanner { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            StudyPlanner = await _context.StudyPlanner.FirstOrDefaultAsync(m => m.plannerID == id);

            if (StudyPlanner == null)
            {
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            StudyPlanner = await _context.StudyPlanner.FindAsync(id);

            if (StudyPlanner != null)
            {
                _context.StudyPlanner.Remove(StudyPlanner);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
