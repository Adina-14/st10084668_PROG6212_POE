﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using st10084668_PROG6212_POE.Model;

namespace st10084668_PROG6212_POE.Pages.StudyPlanners
{
    public class EditModel : PageModel
    {
        private readonly st10084668_PROG6212_POE.Model.AuthDbContext _context;

        public EditModel(st10084668_PROG6212_POE.Model.AuthDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public StudyPlanner StudyPlanner { get; set; }

        public List<SelectListItem> Options { get; set; }
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            StudyPlanner = await _context.StudyPlanner.FirstOrDefaultAsync(m => m.plannerID == id);

            if (StudyPlanner == null)
            {
                return NotFound();
            }
            Options = new SelectList(_context.Module.Where(g => g.username == User.Identity.Name), "moduleCode", "moduleCode").ToList();
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(StudyPlanner).State = EntityState.Modified;

            try
            {
                StudyPlanner.username = User.Identity.Name;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StudyPlannerExists(StudyPlanner.plannerID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool StudyPlannerExists(int id)
        {
            return _context.StudyPlanner.Any(e => e.plannerID == id);
        }
    }
}
