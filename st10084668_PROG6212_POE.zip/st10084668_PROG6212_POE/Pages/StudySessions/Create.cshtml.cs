﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Options;
using st10084668_POE_lib;
using st10084668_PROG6212_POE.Model;
using st10084668_PROG6212_POE.ViewModel;

namespace st10084668_PROG6212_POE.Pages.StudySessions
{
    public class CreateModel : PageModel
    {
        private readonly st10084668_PROG6212_POE.Model.AuthDbContext _context;

        public CreateModel(st10084668_PROG6212_POE.Model.AuthDbContext context)
        {
            _context = context;
        }
        public List<SelectListItem> Options { get; set; }
        public IActionResult OnGet()
        {
            //populates combobox with moduleCodes
            Options = new SelectList(_context.Module.Where(g => g.username == User.Identity.Name), "moduleCode", "moduleCode").ToList();
            return Page();
        }

        [BindProperty]
        public StudySession StudySession { get; set; }

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            StudySession.username = User.Identity.Name;//set username
            //Get start date
            DateTime startdate = DateTime.Now;
            //search database
            var Querydb = _context.Module.Where(u => u.username == User.Identity.Name && u.moduleCode == StudySession.moduleCode);
            var data = Querydb.ToList();

            if (data != null)
            {
                foreach (Module qm in data)
                {
                    startdate = qm.startDate;
                }
            }
                //get class library to calculate work week
                StudySession.workweek = Calculations.workWeek(StudySession.dateOfStudy,startdate);
            _context.StudySession.Add(StudySession);
            await _context.SaveChangesAsync();//save to database

            return RedirectToPage("./Index");
        }
    }
}
