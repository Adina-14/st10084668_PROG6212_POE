﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using st10084668_POE_lib;
using st10084668_PROG6212_POE.Model;

namespace st10084668_PROG6212_POE.Pages.StudySessions
{
    public class DetailsModel : PageModel
    {
        private readonly st10084668_PROG6212_POE.Model.AuthDbContext _context;

        public DetailsModel(st10084668_PROG6212_POE.Model.AuthDbContext context)
        {
            _context = context;
        }

        public StudySession StudySession { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            StudySession = await _context.StudySession.FirstOrDefaultAsync(m => m.SSID == id);

            if (StudySession == null)
            {
                return NotFound();
            }

           

            return Page();
        }
    }
}
