﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using st10084668_POE_lib;
using st10084668_PROG6212_POE.Model;

namespace st10084668_PROG6212_POE.Pages.StudySessions
{
    public class EditModel : PageModel
    {
        private readonly st10084668_PROG6212_POE.Model.AuthDbContext _context;

        public EditModel(st10084668_PROG6212_POE.Model.AuthDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public StudySession StudySession { get; set; }
        public List<SelectListItem> Options { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            StudySession = await _context.StudySession.FirstOrDefaultAsync(m => m.SSID == id);

            if (StudySession == null)
            {
                return NotFound();
            }
            Options = new SelectList(_context.Module.Where(g => g.username == User.Identity.Name), "moduleCode", "moduleCode").ToList();
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(StudySession).State = EntityState.Modified;

            try
            {
                StudySession.username = User.Identity.Name;//set username
                                                           //Get start date
                DateTime startdate = DateTime.Now;
                //search database
                var Querydb = _context.Module.Where(u => u.username == User.Identity.Name && u.moduleCode == StudySession.moduleCode);
                var data = Querydb.ToList();

                if (data != null)
                {
                    foreach (Module qm in data)
                    {
                        startdate = qm.startDate;
                    }
                }
                //get class library to calculate work week
                StudySession.workweek = Calculations.workWeek(StudySession.dateOfStudy, startdate);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StudySessionExists(StudySession.SSID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool StudySessionExists(int id)
        {
            return _context.StudySession.Any(e => e.SSID == id);
        }
    }
}
