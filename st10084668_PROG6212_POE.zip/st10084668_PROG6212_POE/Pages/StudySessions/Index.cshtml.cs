﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using st10084668_PROG6212_POE.Model;

namespace st10084668_PROG6212_POE.Pages.StudySessions
{
    public class IndexModel : PageModel
    {
        private readonly st10084668_PROG6212_POE.Model.AuthDbContext _context;

        public IndexModel(st10084668_PROG6212_POE.Model.AuthDbContext context)
        {
            _context = context;
        }

        public IList<StudySession> StudySession { get;set; }

        public async Task OnGetAsync()
        {
            //Makes sure user only sees their own data
            StudySession = await _context.StudySession.Where(g => g.username == User.Identity.Name).ToListAsync();
        }
    }
}
