﻿using System.ComponentModel.DataAnnotations;

namespace st10084668_PROG6212_POE.ViewModel
{
    public class Login
    {
        [Required]
        public string username { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string password { get; set; }
    }
}
