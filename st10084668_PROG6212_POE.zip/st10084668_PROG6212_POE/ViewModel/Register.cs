﻿using System.ComponentModel.DataAnnotations;

namespace st10084668_PROG6212_POE.ViewModel
{
    public class Register
    {
        [Required]
        public string username { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string password { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Compare(nameof(password),ErrorMessage ="Password and confirmation password did not match")]
        public string confirmpassword { get; set; }
    }
}
